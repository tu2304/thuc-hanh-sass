# Thực hành SASS bằng npm và SASS CLI

Bộ mã có HTML, SCSS gốc và CSS biên dịch. Giải nén, mở thư mục sass-practice trong VS Code bằng File > Open Folder. Mở Terminal > New Terminal tại thư mục chứa package.json.

## 1. Kiểm tra Node.js và npm

```powershell
node -v
npm -v
```
Nếu chưa có, cài Node.js LTS từ https://nodejs.org/en/download rồi mở lại VS Code.

## 2. Cài SASS

```powershell
npm install
npx sass -v
```
Dự án dùng SASS cục bộ. Nếu cần thực hiện đúng lệnh sass -v toàn cục theo đề:

```powershell
npm install -g sass
sass -v
```
Nếu PowerShell chặn npm.ps1, dùng npm.cmd thay npm và npx.cmd thay npx, hoặc chọn terminal Command Prompt. Không cần chuyển ExecutionPolicy sang Unrestricted.

## 3. Biên dịch một file SCSS

```powershell
npx sass --no-source-map scss/styles.scss css/styles.css
```
Hoặc npm run build:single. Mở index.html bằng trình duyệt để xem. HTML liên kết CSS đã tạo, không liên kết SCSS.

## 4. Thực hành watch một file

```powershell
npm run watch:single
```
Lệnh tương đương: npx sass --no-source-map --watch scss/styles.scss:css/styles.css.
Giữ terminal chạy, sửa $primary trong scss/_variables.scss từ #2563eb thành #16a34a, lưu Ctrl+S. Terminal báo biên dịch lại styles.css. Tải lại trình duyệt để thấy nút đổi màu. Nhấn Ctrl+C để dừng.
Watch tự biên dịch CSS, không tự tải lại trình duyệt.

## 5. Biên dịch nhiều file theo thư mục

```powershell
npm run build
npm run watch
```
Lệnh tương đương:

```powershell
npx sass --no-source-map scss:css
npx sass --no-source-map --watch scss:css
```
styles.scss tạo styles.css; extra.scss tạo extra.css. _variables.scss là partial (tên có dấu gạch dưới đầu), dùng qua @use, không xuất CSS riêng.
Thử sửa padding của .badge trong extra.scss rồi lưu để thấy extra.css tự cập nhật. Sửa biến dùng chung thì cả hai CSS được biên dịch lại. Nhấn Ctrl+C để dừng.

## 6. Đưa lên GitHub và nộp link

Cách làm không cần Git:
1. Đăng nhập https://github.com, nhấn + > New repository.
2. Đặt tên thuc-hanh-sass, chọn Public nếu cần giáo viên xem công khai, rồi Create repository.
3. Chọn uploading an existing file, hoặc Add file > Upload files.
4. Kéo nội dung bên trong sass-practice vào: index.html, package.json, package-lock.json, README.md, thư mục scss và css. Không tải node_modules; không chỉ tải file ZIP.
5. Nhấn Commit changes.
6. Sao chép URL repository trên thanh địa chỉ và dán vào phần nộp bài.

Nếu đã có Git, tạo repository rỗng rồi chạy (thay TEN_GITHUB bằng tên thật):

```powershell
git init
git add .
git commit -m "Hoan thanh bai thuc hanh SASS"
git branch -M main
git remote add origin https://github.com/TEN_GITHUB/thuc-hanh-sass.git
git push -u origin main
```

## 7. Minh chứng thực hành

Tự chạy và chụp kết quả node -v, npm -v, sass -v (hoặc npx sass -v); biên dịch một file; biên dịch cả thư mục; watch cập nhật sau khi lưu; trang HTML trên trình duyệt. Các thao tác cài đặt và watch vẫn cần thực hành trên máy của bạn.

Tài liệu chính thức: https://sass-lang.com/install/ và https://sass-lang.com/documentation/cli/dart-sass/.
